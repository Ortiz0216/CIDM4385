class Submit extends React.Component {
    state = {}
    render() {
        return (
            <button type="submit" class="btn btn-primary">Submit</button>
        );
    }
}