class Password extends React.Component {
    state = {}
    render() {
        return (
            <div class="form-group">
                <label for="passowrdInput">Password</label>
                <input type="password" class="form-control" id="passowrdInput" placeholder="Password" />
            </div>
        );
    }
}