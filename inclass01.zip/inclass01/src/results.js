class Results extends React.Component {
    state = {}
    render() {
        return (
            <h4 className="container bg-dark text-white p-3 text-center"></h4>
        );
    }
}